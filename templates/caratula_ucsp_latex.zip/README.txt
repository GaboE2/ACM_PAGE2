Plantilla oficial de carátula ACM UCSP en formato LaTeX.
Compatible con Overleaf y compiladores locales (TeXLive / MiKTeX).